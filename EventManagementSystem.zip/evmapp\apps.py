from django.apps import AppConfig


class EvmappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'evmapp'
